package com.covoiturage.compteuser;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CompteuserApplicationTests {

	@Test
	void contextLoads() {
	}

}
