package com.covoiturage.compteuser.query.entities;

import com.covoiturage.compteuser.commonApi.enums.AccountStatus;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;

import javax.persistence.*;


import java.util.Collection;
import java.util.Date;
@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class Account {
    @Id
    private String id;
    private String firstname;
    private String lastname;
    private String email;
    private String addres;
    private Date birth;
    @Enumerated(EnumType.STRING)
    private AccountStatus status;

    @OneToMany(mappedBy = "account")
    private Collection<Operation> operations;
}
