package com.covoiturage.compteuser.commands.controllers;

import com.covoiturage.compteuser.commonApi.commands.CreateAccountCommand;
import com.covoiturage.compteuser.commonApi.commands.DeleteAccountCommand;
import com.covoiturage.compteuser.commonApi.commands.UpdateAccountCommand;
import com.covoiturage.compteuser.commonApi.dtos.UpdateAccountRequestDTO;
import com.covoiturage.compteuser.commonApi.dtos.createAccountRequestDTO;

import java.util.concurrent.ExecutionException;
import java.util.stream.Stream;

import com.covoiturage.compteuser.query.entities.Account;
import org.axonframework.commandhandling.gateway.CommandGateway;
import org.axonframework.eventsourcing.eventstore.EventStore;
import org.axonframework.messaging.responsetypes.ResponseTypes;
import org.axonframework.queryhandling.QueryGateway;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


import javax.annotation.security.RolesAllowed;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

@RestController
@RequestMapping(path = "/commands/account")
public class AccountCommandController {
    private CommandGateway commandGateway;
    private EventStore eventStore;
    private final QueryGateway queryGateway;



    public AccountCommandController(CommandGateway commandGateway, EventStore eventStore,QueryGateway queryGateway) {
        this.commandGateway = commandGateway;
        this.eventStore = eventStore;
        this.queryGateway = queryGateway;

    }

    @PostMapping(path = "/create")
    @RolesAllowed("user")
    public CompletableFuture<String> createAnnounce(@RequestBody createAccountRequestDTO request) {
        CompletableFuture<String> commandResponse = commandGateway.send(new CreateAccountCommand(
                UUID.randomUUID().toString(),
                request.getFirstname(),
                request.getLastname(),
                request.getEmail(),
                request.getAddres(),
                request.getBirth()
        ));
        return commandResponse;
    }
    @PutMapping(path = "/{accountId}")
    @RolesAllowed("user")
    public CompletableFuture<String> updateAccount(@PathVariable(name = "accountId", required = false) String id, @RequestBody UpdateAccountRequestDTO request) {        CompletableFuture<String> commandResponse = commandGateway.send(new UpdateAccountCommand(
                id,
                request.getFirstname(),
                request.getLastname(),
                request.getEmail(),
                request.getAddres(),
                request.getBirth()
        ));
        return commandResponse.exceptionally(ex -> {
            throw new RuntimeException("Failed to update account: " + ex.getMessage());
        });
    }


    @DeleteMapping(path = "/{accountId}")
    @RolesAllowed("user")
    public ResponseEntity<String> deleteAccount(@PathVariable String accountId) {
        try {
            CompletableFuture<String> commandResponse = commandGateway.send(new DeleteAccountCommand(accountId));
            return ResponseEntity.ok("Account deleted successfully");
        } catch (Exception e) {
            throw new RuntimeException("Failed to delete account: " + e.getMessage());
        }
    }
    @ExceptionHandler()
    public ResponseEntity<String>exceptionHandler(Exception exception)
    {
        ResponseEntity<String> entity= new ResponseEntity<>(
                exception.getMessage(),
                HttpStatus.INTERNAL_SERVER_ERROR
        );
        return entity;
    }

    @GetMapping("/eventStore/{accountId}")
    @RolesAllowed("admin")
    public Stream eventStore(@PathVariable String accountId){
        return (Stream)eventStore.readEvents(accountId).asStream();
    }

}
