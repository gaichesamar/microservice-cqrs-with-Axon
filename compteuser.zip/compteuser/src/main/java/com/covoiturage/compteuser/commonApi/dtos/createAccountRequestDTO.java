package com.covoiturage.compteuser.commonApi.dtos;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
@Data
@NoArgsConstructor
@AllArgsConstructor
public class createAccountRequestDTO {
    private String firstname;
    private String lastname;
     private String email;
     private String addres;
     private Date birth;
}
