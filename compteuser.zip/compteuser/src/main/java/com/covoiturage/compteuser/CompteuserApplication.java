package com.covoiturage.compteuser;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CompteuserApplication {

	public static void main(String[] args) {
		SpringApplication.run(CompteuserApplication.class, args);
	}

}
