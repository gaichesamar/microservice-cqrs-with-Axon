package com.covoiturage.compteuser.commonApi.enums;

public enum OperationType {
    Create,Read,Update,Delete
}
