package com.covoiturage.compteuser.query.repositories;

import com.covoiturage.compteuser.query.entities.Account;
import com.covoiturage.compteuser.query.entities.Operation;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AccountRepository extends JpaRepository<Account,String> {
        }
