package com.covoiturage.compteuser.commonApi.dtos;

import lombok.Data;

import java.util.Date;
@Data
public class UpdateAccountRequestDTO {
    private String id;
    private String firstname;
    private String lastname;
    private String email;
    private String addres;
    private Date birth;
}
