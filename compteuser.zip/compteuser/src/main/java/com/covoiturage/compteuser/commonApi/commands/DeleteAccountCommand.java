package com.covoiturage.compteuser.commonApi.commands;

public class DeleteAccountCommand {
    private final String accountId;

    public DeleteAccountCommand(String accountId) {
        this.accountId = accountId;
    }

    public String getAccountId() {
        return accountId;
    }
}