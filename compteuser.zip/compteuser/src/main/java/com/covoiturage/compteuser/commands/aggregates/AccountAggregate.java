package com.covoiturage.compteuser.commands.aggregates;

import com.covoiturage.compteuser.commonApi.commands.CreateAccountCommand;
import com.covoiturage.compteuser.commonApi.commands.DeleteAccountCommand;
import com.covoiturage.compteuser.commonApi.commands.UpdateAccountCommand;
import com.covoiturage.compteuser.commonApi.enums.AccountStatus;
import com.covoiturage.compteuser.commonApi.events.AccountCreatedEvent;
import com.covoiturage.compteuser.commonApi.events.AccountDeletedEvent;
import com.covoiturage.compteuser.commonApi.events.AccountUpdatedEvent;
import com.covoiturage.compteuser.commonApi.events.AccountValidatedEvent;
import org.apache.commons.lang.NullArgumentException;
import org.axonframework.commandhandling.CommandHandler;
import org.axonframework.eventsourcing.EventSourcingHandler;
import org.axonframework.modelling.command.AggregateIdentifier;
import org.axonframework.modelling.command.AggregateLifecycle;
import org.axonframework.spring.stereotype.Aggregate;

import java.util.Date;

@Aggregate
public class AccountAggregate {
    @AggregateIdentifier
    private String AccountId;
    private String firstname;
    private String lastname;
    private String email;
    private String addres;
    private Date birth;
    private AccountStatus status;

    public AccountAggregate() {
        //Required by Axon
    }

    @CommandHandler
    public AccountAggregate(CreateAccountCommand createAccountCommand) {
        //Required by Axon
        if ((createAccountCommand.getFirstname() == null) ||
                (createAccountCommand.getLastname() == null) ||
                (createAccountCommand.getEmail() == null ||
                        (createAccountCommand.getAddres() == null) ||
                        (createAccountCommand.getBirth() == null))) {
            throw new RuntimeException("Inputs should not be null");
        }
        AggregateLifecycle.apply(new AccountCreatedEvent(
                createAccountCommand.getId(),
                createAccountCommand.getFirstname(),
                createAccountCommand.getLastname(),
                createAccountCommand.getEmail(),
                createAccountCommand.getAddres(),
                createAccountCommand.getBirth()

        ));
    }

    @EventSourcingHandler
    public void on(AccountCreatedEvent event) {
        this.AccountId = event.getId();
        this.firstname = event.getFirstname();
        this.lastname = event.getLastname();
        this.email = event.getEmail();
        this.addres = event.getAddres();
        this.birth = event.getBirth();
        this.status = AccountStatus.CREATED;
        AggregateLifecycle.apply(new AccountValidatedEvent(
                event.getId(),
                AccountStatus.VALIDATED
        ));
    }

    @EventSourcingHandler
    public void on(AccountValidatedEvent event) {
        this.status = event.getStatus();
    }

    @CommandHandler
    public void handle(UpdateAccountCommand command) {
        //Required by Axon
        if ((command.getFirstname() == null) ||
                (command.getLastname() == null) ||
                (command.getEmail() == null ||
                        (command.getAddres() == null) ||
                        (command.getBirth() == null))) {
            throw new RuntimeException("Inputs should not be null");
        }
        AggregateLifecycle.apply(new AccountCreatedEvent(
                command.getId(),
                command.getFirstname(),
                command.getLastname(),
                command.getEmail(),
                command.getAddres(),
                command.getBirth()

        ));
    }

    @EventSourcingHandler
    public void on(AccountUpdatedEvent event) {
        this.firstname = event.getFirstname();
        this.lastname = event.getLastname();
        this.email = event.getEmail();
        this.addres = event.getAddres();
        this.birth = event.getBirth();
        this.status = AccountStatus.UPDATED;
    }

    @CommandHandler
    public void handle(DeleteAccountCommand command) {
        AggregateLifecycle.apply(new AccountDeletedEvent(command.getAccountId()));
    }

    @EventSourcingHandler
    public void on(AccountDeletedEvent event) {
        this.status = AccountStatus.DELETED;
    }
}
