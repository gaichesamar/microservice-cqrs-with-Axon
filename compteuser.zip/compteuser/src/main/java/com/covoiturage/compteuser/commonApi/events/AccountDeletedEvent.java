package com.covoiturage.compteuser.commonApi.events;

public class AccountDeletedEvent {
    private String id;

    public AccountDeletedEvent() {
        // Required by frameworks such as Axon
    }

    public AccountDeletedEvent(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
