package com.covoiturage.compteuser.query.services;

public class AccountQueryHandler {
}
