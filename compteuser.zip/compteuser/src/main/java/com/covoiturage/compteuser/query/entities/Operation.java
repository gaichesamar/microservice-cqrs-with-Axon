package com.covoiturage.compteuser.query.entities;

import com.covoiturage.compteuser.commonApi.enums.OperationType;

import javax.persistence.*;
import java.util.Date;

@Entity
public class Operation {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private String id;
    private Date date;
    @Enumerated(EnumType.STRING)
    private OperationType operationType;

    @ManyToOne
    private Account account;

}