package com.covoiturage.compteuser.query.services;

import com.covoiturage.compteuser.commonApi.events.AccountCreatedEvent;
import com.covoiturage.compteuser.query.entities.Account;
import com.covoiturage.compteuser.query.repositories.AccountRepository;
import com.covoiturage.compteuser.query.repositories.OperationRepository;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.axonframework.eventhandling.EventHandler;
import org.springframework.stereotype.Service;



@AllArgsConstructor
@Slf4j
@Service
public class AccountServiceHandler {
    private AccountRepository accountRepository;

    private OperationRepository operationRepository;
    @EventHandler
    public void on(AccountCreatedEvent event){
        log.info("************************");
        log.info("AccountCreatedEvent received");
        Account account = new Account();
       account.setId(event.getId());
       account.setFirstname(event.getFirstname());
       account.setLastname(event.getLastname());
       account.setAddres(event.getAddres());
       account.setEmail(event.getEmail());
       account.setBirth(event.getBirth());
        account.setStatus(event.getStatus());
        accountRepository.save(account);
    }

}