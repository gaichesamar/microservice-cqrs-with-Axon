package com.covoiturage.compteuser.commonApi.events;

import lombok.Getter;

import java.util.Date;

public class AccountUpdatedEvent extends BaseEvent<String>{

    @Getter
    private String firstname;
    @Getter
    private String lastname;
    @Getter private String email;
    @Getter private String addres;
    @Getter private Date birth;


    public  AccountUpdatedEvent (String id, String firstname, String lastname, String email , String addres, Date birth)

    {
        super(id);
        this.firstname=firstname;
        this.lastname=lastname;
        this.email=email;
        this.addres=addres;
        this.birth=birth;


    }

}