package com.covoiturage.compteuser.commonApi.commands;

import lombok.Getter;

import java.sql.Time;
import java.util.Date;

public class CreateAccountCommand extends baseCommand<String> {
    @Getter
    private String firstname;
    @Getter
    private String lastname;
    @Getter private String email;
    @Getter private String addres;
    @Getter private Date birth;


    public CreateAccountCommand (String id, String firstname, String lastname, String email , String addres, Date birth)

    {
        super(id);
        this.firstname=firstname;
        this.lastname=lastname;
        this.email=email;
        this.addres=addres;
        this.birth=birth;


    }

}
