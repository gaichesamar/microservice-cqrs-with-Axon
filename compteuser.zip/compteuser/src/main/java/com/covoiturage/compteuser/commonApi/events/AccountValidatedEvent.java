package com.covoiturage.compteuser.commonApi.events;

import com.covoiturage.compteuser.commonApi.enums.AccountStatus;
import lombok.Getter;

public class AccountValidatedEvent extends BaseEvent<String>{
    @Getter
    private AccountStatus status;
    public   AccountValidatedEvent (String id, AccountStatus status)
    {
        super(id);
        this.status=status;
    }
}