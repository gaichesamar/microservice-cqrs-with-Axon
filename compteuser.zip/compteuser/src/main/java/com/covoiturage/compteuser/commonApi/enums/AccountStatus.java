package com.covoiturage.compteuser.commonApi.enums;


public enum AccountStatus {
    CREATED,VALIDATED,UPDATED,DELETED
}
